# Mobile Application to Improve Nurse Mental Health and Burnout

To run the streamlit app, run the following commands in the command line:
1. `pip install streamlit`
2. `streamlit run nurse_app.py`